//prompt for list of plyayers BEFORE the list of teams (both for adding & removing)
//Fix remove method
//Make LeguaReport method
//Fix invalid input erros
//Tidy up input/output layout

package com.teamtreehouse.model;

import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Run {
  public Team team;
  public String teamName;
  public String coachName;
  public String teamChoice;
  public Set<Team> teams;
  public Scanner scanner;
  public Player player;
  public Player[] listOfPlayers;
  public List<Player> playerList;
  public Set<Player> playerSet;
  private Map<String, String>rMenu;
  private BufferedReader mReader;
  
  public Run() {
    team = new Team(teamName, coachName);
    teams = new TreeSet<Team>();
    listOfPlayers = Players.load();
    playerList = Arrays.asList(listOfPlayers);
    playerSet = new TreeSet<Player>(playerList);
    scanner = new Scanner(System.in);
    rMenu = new HashMap<String, String>();
    mReader = new BufferedReader(new InputStreamReader(System.in));
  }

  public void displayMenu() {
    System.out.print("\n");
    System.out.print("=========MENU=========\n");
    System.out.print("create - create a new team\n");
    System.out.print("add - add a player to a team\n");
    System.out.print("remove - remove a player from a team\n");
    System.out.print("roster - compare chosen teams players stats\n");
    System.out.print("print - print chosen teams players\n");
    System.out.println("exit - exit the program\n");
  }
  
  public String promptForOption() throws IOException {
    System.out.printf("Select an option: ");
    String answer = scanner.nextLine();
    return answer;
  }
  
  public Team promptForNewTeam() throws IOException {
    do {
      System.out.print("\n");
      System.out.print("What is your team name? ");
      teamName = scanner.nextLine();
    } while(teamName.isEmpty());
    do {
      System.out.print("What is your coach name? ");
      coachName = scanner.nextLine();
    } while (coachName.isEmpty());
    return new Team(teamName, coachName);
  }
  
  public String promptForTeam() throws IOException {
    System.out.print("\n");
    System.out.print("***AVAILABLE TEAMS***\n");
    for (Team team : teams) {
      System.out.println(team.getTeamName());
    }
    System.out.print("\n");
    String choice = scanner.nextLine();
    return choice;
  }
  
  public Player promptForAvailablePlayers(String teamChoice) throws IOException {
    List<String> roster = new ArrayList<String>();
    List<Player> mPlayers = new ArrayList<Player>(playerSet);
    System.out.printf("***%s available players to choose from***\n", teamChoice);
    System.out.println(" ");
    for(Player player : mPlayers) {
      roster.add(player.getLastName() + " " + player.getFirstName() + " (Height: " +
                 player.getHeightInInches() + " inches - Experienced " +
                 player.isPreviousExperience() + ")");
    }  
    int index = promptForPosistion(roster);
    return mPlayers.get(index);
  }
  
  public int promptForPosistion(List<String> posistion) throws IOException {
    int choice = 1;
    try {
      for (String player : posistion) {
        System.out.printf("%d.)%s\n", choice, player);
        choice++;
      }
      System.out.print("\n");
      System.out.print("Select an option: ");
      String choiceAsString = scanner.nextLine();
      choice = Integer.parseInt(choiceAsString.trim());
    } catch(IllegalArgumentException iae) {
      System.out.print("problem with index" + iae.getMessage());
    }
    return choice -1;
  }
  
  public Player promptTeamsPlayers(String teamChoice, Set<Player> mPlayers) throws IOException {
    List<String> roster = new ArrayList<>();
    List<Player> players = new ArrayList<>(mPlayers);
    for(Player player : players) {
      roster.add(player.getLastName() + " " + player.getFirstName() + " (Height: " +
                 player.getHeightInInches() + " inches - Experienced " +
                 player.isPreviousExperience() + ")");
    }
    int posistion = promptForPosistion(roster);
    return players.get(posistion);
  }
  
  private Map<String, Set<String>> byHeight(Set<Player> roster) {
   Map<String, Set<String>> heightMap = new TreeMap<>();
     Set<String> groupA = new TreeSet<>();
     Set<String> groupB = new TreeSet<>();
     Set<String> groupC = new TreeSet<>();
     String params1 = "Height range between 35 and 40 in.";
     String params2 = "Height range between 41 and 46 in.";
     String params3 = "Height range between 47 and 50 in.";
    
     for (Player player : roster) {
       if(player.getHeightInInches() >= 35 && player.getHeightInInches() <= 40) {
         groupA.add(player.getLastName() + " " + player.getFirstName() + " (Height: " +
                 player.getHeightInInches() + " inches - Experienced " +
                 player.isPreviousExperience() + ")");
       } else if (player.getHeightInInches() >= 41 && player.getHeightInInches() <= 46) {
         groupB.add(player.getLastName() + " " + player.getFirstName() + " (Height: " +
                 player.getHeightInInches() + " inches - Experienced " +
                 player.isPreviousExperience() + ")");
       } else if (player.getHeightInInches() >= 47 && player.getHeightInInches() <= 50) {
         groupC.add(player.getLastName() + " " + player.getFirstName() + " (Height: " +
                 player.getHeightInInches() + " inches - Experienced " +
                 player.isPreviousExperience() + ")");
       } else {
         System.out.println("An error occurred printing the roster by height."); 
       }
     }
    
     heightMap.put(params1, groupA);
     heightMap.put(params2, groupB);
     heightMap.put(params3, groupC);

    for (Map.Entry<String, Set<String>> entry : heightMap.entrySet()) {
      System.out.println("\n" + entry.getKey() + "\n");
      List<String> group = new ArrayList<>(entry.getValue());
         for (String player : group) {
          
          System.out.println(player);
         }
    }
    return heightMap;
  }
  
  private String promptReports() throws IOException {
    System.out.print("\n");
    System.out.println("Which report would you like to see:\n");
    System.out.println("-height");
    System.out.println("-experience\n");
    for (Map.Entry<String, String> option : rMenu.entrySet()) {
      System.out.printf("%s - %s %n",
                        option.getKey(),
                        option.getValue());
    }
    String choice = mReader.readLine();
    return choice.trim().toLowerCase();
  }
  
  private Player promptRoster(String teamChoice, Set<Player> roster) throws IOException {
    List<String> mRoster = new ArrayList<>();
    List<Player> players = new ArrayList<>(roster);
    for (Player player : players) {
      mRoster.add(player.getLastName() + ", " + player.getFirstName() + " || Height:  " + player.getHeightInInches() + " in.  Experienced:  " + player.isPreviousExperience());
      
   }
    System.out.printf("Players for the %s: %n", teamChoice);
    int index = promptForPosistion(mRoster);
    return players.get(index);
  }   
  
  public Set<String> groupByHeight(Set<Player> roster) {
    return byHeight(roster).keySet();
  }
  
  public Map<String, String> byExperience() {
    Map<String, String> experienceMap = new TreeMap<>();
    for (Team team : teams) {
      String mTeam = team.getTeamName();
      int group1 = 0;
      int group2 = 0;
      String inex = "Number of INEXPERIENCED players";
      String exper = "Number of EXPERIENCED players";
      Set<Player> mPlayers = team.getTeamsPlayers();
      for (Player player : mPlayers) {
        boolean check = player.isPreviousExperience();
        if(!check) {
          group1++;
        } else {
          group2++;
        }
      }
      System.out.print("\n");
      System.out.printf("***Team %s player stats***\n", mTeam);
      System.out.println("EXPERIENCED PLAYERS: " + Integer.toString(group2));
      System.out.println("INEXPERIENCED PLAYERS: " + Integer.toString(group1));
    }
    return experienceMap;
  }
  public Set<String> groupByExperienced() {
    return byExperience().keySet();
  }
  
  public void printTeamsPlayers (Set<Player> roster) {
    int counter = 1;
    List<Player> mRoster = new ArrayList<>();
    List<Player> players = new ArrayList<>(roster);
    for (Player player : players) {
      System.out.printf("%d) %s %s (Height: %s inches - Experienced %s\n",
                       counter,
                       player.getLastName(),
                       player.getFirstName(),
                       player.getHeightInInches(),
                       player.isPreviousExperience());
        counter++;
    }
  }
  
  public void run() {
    String option = "";
    Set<Player> mListOfPlayers = new TreeSet<Player>();
    do {
      displayMenu();
      try {
        option = promptForOption();
        
        switch (option) {
          case "create":
          team = promptForNewTeam();
          teams.add(team);
         break;
          
          case "add":
          if (teams.isEmpty()) {
            System.out.print("There are NO teams available, please create a team first\n");
          } else {
            teamChoice = promptForTeam();
            for(Team team : teams) {
              if (team.getTeamName().equals(teamChoice)) {
                mListOfPlayers = team.getTeamsPlayers();
                System.out.print("\n");
                System.out.printf("The %s have %d players\n", 
                                  teamChoice,
                                  mListOfPlayers.size());
                System.out.print("\n");
                if(mListOfPlayers.size() == team.getMaxPlayers()) {
                  System.out.printf("You have reached the maximum amount of players you can add to a team");
                } else {
                  if (playerList.isEmpty()) {
                    System.out.print("All teams are full, there are no plyaers left");
                    System.out.print("\n");
                  } else {
                    player = promptForAvailablePlayers(teamChoice);
                    team.addPlayer(player);
                    playerSet.remove(player);
                    System.out.printf("You added %s %s to %s and now has %d players",
                                     player.getFirstName(),
                                     player.getLastName(),
                                     teamChoice,
                                     mListOfPlayers.size()
                                     );
                    System.out.print("\n");
                  }
                }
              }
            }
          }
         break;
          case "remove":
          if (teams.isEmpty()) {
            System.out.println("There are no teams to remove players from");
          } else {
            teamChoice = promptForTeam();
            for (Team team : teams) {
              if (team.getTeamName().equals(teamChoice)) {
                mListOfPlayers = team.getTeamsPlayers();
                System.out.print("\n");
                System.out.printf("The %s have %d player(s)\n", teamChoice, mListOfPlayers.size());
                System.out.print("\n");
                if (mListOfPlayers.size() <= 0) {
                  System.out.println("There are no players to remove from this team");
                } else {
                  player = promptRoster(teamChoice, mListOfPlayers);
                  System.out.printf("Player is %s", player);
                  team.removePlayer(player);
                  System.out.printf("You removed %s %s from team %s and now has %s players",
                                   player.getLastName(), player.getFirstName(), teamChoice, 
                                   mListOfPlayers.size());
                  System.out.print("\n");
                }
              }
            }
          }
         break;
          case "roster":
          if (teams.isEmpty()) {
            System.out.println("There are no created teams. Create a team first ");
          } else {
            String report = promptReports();
              if (report.equals("height")) {
                teamChoice = promptForTeam();
                for(Team team : teams) {
                  if(team.getTeamName().equals(teamChoice)) {
                    mListOfPlayers = team.getTeamsPlayers();
                    groupByHeight(mListOfPlayers);
                }
              }
            } else if (report.equals("experience")) {
                groupByExperienced();
              }
          }
         break;
          case "print":
          if (teams.isEmpty()) {
            System.out.println("There are no created teams");
          } else {
            for (Team team : teams) {
              teamChoice = promptForTeam();
              if (team.getTeamName().equals(teamChoice)) {
                mListOfPlayers = team.getTeamsPlayers();
                System.out.printf("Available players for team %s\n", teamChoice);
                System.out.print("\n");
                if (mListOfPlayers.size() <= 0) {
                  System.out.printf("There are no players for team %s\n", teamChoice);
                  System.out.print("\n");
                } else {
                  printTeamsPlayers(mListOfPlayers);
                }
              }
            }
          }
         break;
          case "exit":
          System.out.print("Good luck!!!\n");
         break;
          default:
          System.out.println("Please select a valid option from the menu");
         break;
        }
      }catch(IOException ioe) {
        System.out.println("Problem with input");
        ioe.printStackTrace();
      }
    }while(!option.equals("exit"));
  }
}
